#include "summoner.h"
#include <TlHelp32.h>

DWORD get_module(DWORD pid, char *module_name) {
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
	MODULEENTRY32 me32;
	me32.dwSize = sizeof(MODULEENTRY32);

	while (Module32Next(snapshot, &me32)) {
		if (strcmp(me32.szModule, module_name) == 0) {
			return (DWORD)me32.modBaseAddr;
		}
	} return NULL;
}