#include "summoner.h"
#include "lowlvl.h"
#include <stdio.h>
#include <vector>
#include <math.h>

HANDLE handle;
DWORD hng;

// enemies
struct enemyStruct {
	float x, y, z;
	float aim_x;
	DWORD dword;
};
std::vector<enemyStruct> unassEnemies;
std::vector<enemyStruct> assEnemies; //        <-------------+
int local_player_pos = 0;            // position in this arr |

// Find is enemy  in our array
bool isThereEnemy(DWORD target_value, std::vector<enemyStruct> vector) {
	for (unsigned short i = 0; i < vector.size(); i++) {
		if (vector[i].dword == target_value) return true;
	} return false;
}
// little overflow
bool isThereEnemy(DWORD target_value, std::vector<enemyStruct> vector, int *pos) {
	for (unsigned short i = 0; i < vector.size(); i++) {
		if (vector[i].dword == target_value) {
			*pos = i;
			return true;
		}
	} return false;
}

HDC hdc_hng;
HBRUSH blueBrush;
HBRUSH greenBrush;
HBRUSH redBrush;
HBRUSH blackBrush;

void draw_player(float x, float z, HBRUSH brush) {
	RECT rect = { x + 400, z + 600, x + 400 +2, z + 600 +2 };
	FillRect(hdc_hng, &rect, brush);
}

float getOldDaysAim(float newAim) {
	newAim = std::abs(newAim);
	while (newAim > 6.284981728f) newAim -= 6.284981728f;
	return newAim;
}

// 28 - x foat
// 2C - y float
// 30 - z float
// 64 - hp int
// 40 - aim x
// 48 - aim y

// Aimbot thread
DWORD WINAPI _aimbotThread(LPVOID) {
	for (;; Sleep(10)) {
		// clearing view
		//RECT rect = { 0, 0, 600, 600 };
		//FillRect(hdc_hng, &rect, blackBrush);

		// going to check if enemy is playing, x != 0 and hp != 0
		DWORD orrandomdw;

		for (unsigned short i = 0; i < unassEnemies.size(); i++) {
			float my_aim_x;
			ReadProcessMemory(handle, (LPVOID)(hng + 0x63057C), &orrandomdw, 4, 0);
			ReadProcessMemory(handle, (LPVOID)(orrandomdw + 0x4c8), &my_aim_x, 4, 0);

			float x, y, z; // 28
			ReadProcessMemory(handle, (LPVOID)(unassEnemies[i].dword + 0x28), &x, 4, 0); // slow
			ReadProcessMemory(handle, (LPVOID)(unassEnemies[i].dword + 0x28 +4), &y, 4, 0); // fuking slow
			ReadProcessMemory(handle, (LPVOID)(unassEnemies[i].dword + 0x28 +8), &z, 4, 0); // like snail

			int hp; // 5C ah i know already what happening ^^, value 255 means its dead
			ReadProcessMemory(handle, (LPVOID)(unassEnemies[i].dword + 0x64), &hp, 4, 0);

			float aim_x;
			ReadProcessMemory(handle, (LPVOID)(unassEnemies[i].dword + 0x40), &aim_x, 4, 0);

			if (x != 0 && hp > 255) {
				int pos;
				if (isThereEnemy(unassEnemies[i].dword, assEnemies, &pos) == false) {
					enemyStruct use;
					use.dword = unassEnemies[i].dword;
					use.x = x;
					use.y = y;
					use.z = z;
					use.aim_x = getOldDaysAim(aim_x);
					assEnemies.push_back(use);

					if (my_aim_x == aim_x) {
						//printf("we got new local player: dw = %x\n", unassEnemies[i].dword);
						printf("my aim x: %f\n", use.aim_x);
						local_player_pos = pos;
						//draw_player(x, z, greenBrush);
					} else {
						// drawing unknown target
						//draw_player(x, z, redBrush);
					}
				}
			}
		}


		// clearing signed enemyes to get new ones to deal with
		assEnemies.clear();
	}

	return 0;
}

int main() {
	HWND hwnd = FindWindowA(0, "H&G");

	if (hwnd) {
		hdc_hng = GetDC(GetConsoleWindow());
		blueBrush = CreateSolidBrush(RGB(0, 0, 255));
		greenBrush = CreateSolidBrush(RGB(0, 255, 0));
		redBrush = CreateSolidBrush(RGB(255, 0, 0));
		blackBrush = CreateSolidBrush(RGB(0, 0, 0));

		DWORD pid;
		GetWindowThreadProcessId(hwnd, &pid);

		hng = get_module(pid, "_hng.exe");
		handle = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, false, pid);

		if (handle) {
			DWORD target_addr = hng + 0x5B5084;

			// mov [someaddr], edi      write unto "useless" address
			WriteProcessMemory(handle, (LPVOID)(hng + 0x1849A8), "\x89\x35", 2, 0);
			// writing dword so we get mov [target_addr], edi
			WriteProcessMemory(handle, (LPVOID)(hng + 0x1849A8 + 2), &target_addr, 4, 0);
			WriteProcessMemory(handle, (LPVOID)(hng + 0x1849A8 + 2 + 4), "\x90", 1, 0); // and finally 1 nop
			
			// creating thread thats going to fill enemy struct
			CreateThread(0, 0, _aimbotThread, 0, 0, 0);

			for (;; Sleep(10)) {
				// getting target struct start value
				DWORD target_value;
				ReadProcessMemory(handle, (LPVOID)(target_addr), &target_value, 4, 0);
				
				if (isThereEnemy(target_value, unassEnemies) == false) {
					enemyStruct use;
					use.dword = target_value;
					unassEnemies.push_back(use);
				}
			}
		}
	}

	return 0;
}

