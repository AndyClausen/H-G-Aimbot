#pragma once
#include <Windows.h>

DWORD get_module(DWORD pid, char *module_name);